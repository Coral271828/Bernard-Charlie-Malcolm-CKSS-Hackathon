# our team

name: The Operation Aggregation

members:
* Bernard
1. Charlie
* Malcolm

# the theme

is "teen financial literacy"

# the problem (which we chose to solve)

## (ideas)

* Needs vs wants (impulse control)
* (there are no other ideas)

# the solution

1. How to set achievable financial goals
   * 
2. Strategies for developing healthy spending spending habits
   * Give ways to determine if something 
3. Keeping track of spending
   * Planing spending and income:
     * Give example formats of planners to keep track of budget and spending (subsriptions, allowance, purchases)
     * A planner you can fill out and it calculates if you're saving enough money and spending a healthy amount


